pokemonTypes = [
  {
    "english": "Normal",
    "chinese": "一般",
    "japanese": "ノーマル"
  },
  {
    "english": "Fighting",
    "chinese": "格斗",
    "japanese": "かくとう"
  },
  {
    "english": "Flying",
    "chinese": "飞行",
    "japanese": "ひこう"
  },
  {
    "english": "Poison",
    "chinese": "毒",
    "japanese": "どく"
  },
  {
    "english": "Ground",
    "chinese": "地上",
    "japanese": "じめん"
  },
  {
    "english": "Rock",
    "chinese": "岩石",
    "japanese": "いわ"
  },
  {
    "english": "Bug",
    "chinese": "虫",
    "japanese": "むし"
  },
  {
    "english": "Ghost",
    "chinese": "幽灵",
    "japanese": "ゴースト"
  },
  {
    "english": "Steel",
    "chinese": "钢",
    "japanese": "はがね"
  },
  {
    "english": "Fire",
    "chinese": "炎",
    "japanese": "ほのお"
  },
  {
    "english": "Water",
    "chinese": "水",
    "japanese": "みず"
  },
  {
    "english": "Grass",
    "chinese": "草",
    "japanese": "くさ"
  },
  {
    "english": "Electric",
    "chinese": "电",
    "japanese": "でんき"
  },
  {
    "english": "Psychic",
    "chinese": "超能",
    "japanese": "エスパー"
  },
  {
    "english": "Ice",
    "chinese": "冰",
    "japanese": "こおり"
  },
  {
    "english": "Dragon",
    "chinese": "龙",
    "japanese": "ドラゴン"
  },
  {
    "english": "Dark",
    "chinese": "恶",
    "japanese": "あく"
  },
  {
    "english": "Fairy",
    "chinese": "妖精",
    "japanese": "フェアリー"
  }
]
